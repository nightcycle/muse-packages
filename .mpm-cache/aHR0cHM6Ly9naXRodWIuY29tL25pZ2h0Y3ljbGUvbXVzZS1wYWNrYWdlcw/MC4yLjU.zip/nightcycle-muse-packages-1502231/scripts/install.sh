#!/usr/bin/env bash
./mpm.exe install